
# Inventory App - Room Parte 3

Este proyecto corresponde al ejercicio 3 del codelab "Cómo leer y actualizar datos con Room", 
integrado al repositorio existente.

Incluye:
- Pantalla de detalle de ítems.
- Pantalla de edición.
- Lógica de navegación y uso de DAO `update()`.
- Uso de `Flow` y `collectAsState()`.

**Alumno:** Kevin Sarabia  
**Curso:** IPDM OTO 2025
