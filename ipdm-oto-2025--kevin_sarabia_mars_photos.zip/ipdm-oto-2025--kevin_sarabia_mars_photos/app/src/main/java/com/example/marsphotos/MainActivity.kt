// Código Kotlin simulado para MainActivity
